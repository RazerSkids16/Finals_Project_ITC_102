-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 28, 2019 at 11:29 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project404`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`ID`, `username`, `password`) VALUES
(2, 'Reymar', 'Sumangue'),
(3, 'admin', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Idnumber` varchar(45) NOT NULL,
  `Fname` varchar(45) NOT NULL,
  `Age` varchar(45) NOT NULL,
  `Address` varchar(45) NOT NULL,
  `Gender` varchar(45) NOT NULL,
  `Course` varchar(45) NOT NULL,
  `Civilstats` varchar(45) NOT NULL,
  `Sem` varchar(45) NOT NULL,
  `Comprog` varchar(45) NOT NULL,
  `Hci` varchar(45) NOT NULL,
  `Math` varchar(45) NOT NULL,
  `Arts` varchar(45) NOT NULL,
  `Hist10` varchar(45) NOT NULL,
  `Hist11` varchar(45) NOT NULL,
  `Gpa` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `Idnumber`, `Fname`, `Age`, `Address`, `Gender`, `Course`, `Civilstats`, `Sem`, `Comprog`, `Hci`, `Math`, `Arts`, `Hist10`, `Hist11`, `Gpa`) VALUES
(19, '2018-1942', 'Rachel Ann Ligad', '19', 'Sudlon Riverside', 'Female', 'BSIT', 'Single', 'Second', '2', '1', '1', '2', '2', '1', '1.3333333333333333'),
(21, '2016-3214', 'Ricardo Dalisay', '34', 'Talisay-2', 'Male', 'BSCrim', 'Married', 'Second', '3', '2', '2', '3', '3', '2', '2.3333333333333335');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
